package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.Admin;

public interface AdminDao extends JpaRepository<Admin, String> {

}
