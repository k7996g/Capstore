package com.cg.capstore.dao;

public interface IDao 
{
	public boolean returnGood(int prodid);

}
