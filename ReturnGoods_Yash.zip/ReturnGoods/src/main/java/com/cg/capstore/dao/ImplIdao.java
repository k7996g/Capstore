package com.cg.capstore.dao;

import java.time.LocalDate;
import java.time.Period;

public class ImplIdao implements IDao {

	@Override
	public boolean returnGood(int prodid) 
	{
		Product product=em.find(prodid);
		LocalDate today = LocalDate.now();
		Period period = Period.between(today, product.purchaseDate);
		if(period.getDays()<=30)
		{
			return true;
			
		}
		return false;
		
	}

}
