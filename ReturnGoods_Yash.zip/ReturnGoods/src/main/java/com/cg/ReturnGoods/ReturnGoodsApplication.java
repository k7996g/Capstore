package com.cg.ReturnGoods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReturnGoodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReturnGoodsApplication.class, args);
	}

}
