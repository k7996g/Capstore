package com.capgemini.RegisterCustomer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.RegisterCustomer.bean.Address;
import com.capgemini.RegisterCustomer.bean.Customer;
import com.capgemini.RegisterCustomer.bean.Merchant;
import com.capgemini.RegisterCustomer.exception.CustomerAlreadyExist;
import com.capgemini.RegisterCustomer.repo.ICustomerRepository;



@Service("service")
public class CustomerService implements ICustomerService{

	@Autowired
	ICustomerRepository repo;
	
	@Override
	public Customer registerCustomer(Customer customer) throws CustomerAlreadyExist {
		if(repo.findCustomerByMobileNo(customer.getCustomer_mobile_no()) == null)
			return repo.registerCustomer(customer) ;
		else
			throw new CustomerAlreadyExist("Customer Already exist with this Mobile Number");
		
	}

	@Override
	public Address addAddress(Address address,String id) {
		return repo.addAddress(address,id);
	}

	
}
