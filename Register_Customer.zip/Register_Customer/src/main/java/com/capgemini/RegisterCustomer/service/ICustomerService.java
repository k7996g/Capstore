package com.capgemini.RegisterCustomer.service;

import com.capgemini.RegisterCustomer.bean.Address;
import com.capgemini.RegisterCustomer.bean.Customer;
import com.capgemini.RegisterCustomer.bean.Merchant;
import com.capgemini.RegisterCustomer.exception.CustomerAlreadyExist;

public interface ICustomerService {

	public Customer registerCustomer(Customer customer) throws CustomerAlreadyExist ;
	public Address addAddress(Address address, String id);
}
