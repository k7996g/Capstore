package com.capgemini.RegisterCustomer.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.capgemini.RegisterCustomer.bean.Address;
import com.capgemini.RegisterCustomer.bean.Cart;
import com.capgemini.RegisterCustomer.bean.Customer;
import com.capgemini.RegisterCustomer.bean.WishList;


import oracle.net.aso.l;

@Transactional
@Repository("repo")
public class CustomerRepository implements  ICustomerRepository{

	@PersistenceContext
	EntityManager entity;
	
	@Override
	public Customer registerCustomer(Customer customer) {
		System.out.println(customer);
		Random random=new Random();
		String cartId="C#"+Integer.toString(random.nextInt(100));
		String wishlistId="W#"+Integer.toString(random.nextInt(100));
		
		Cart cart=new Cart();
		cart.setCart_id(cartId);
		WishList wish=new WishList();
		wish.setWishlist_id(wishlistId);
		
		customer.setCart(cart);
		customer.setWishlist(wish);
		
		customer.setActive(true);
		
		entity.persist(customer);
		
		System.out.println(customer);
		
		return customer;
	}

	@Override
	public Address addAddress(Address address,String id) {
		
		System.out.println(address);
		Random random=new Random();
		String addressId="A#"+Integer.toString(random.nextInt(100));
		address.setAddress_id(addressId);
		
		List<Address> list=new ArrayList<>();
		list.add(address);
		
		
		Customer customer=entity.find(Customer.class,id);
		customer.setAdresses(list);
		System.out.println(customer.getCustomer_mobile_no());
		
		address.setCustomer_id(customer);
		entity.merge(customer);
		
		System.out.println(address.getAddress_id());
		
		return address;
	}

	@Override
	public Customer findCustomerByMobileNo(String customer_mobile_no) {
		Customer customer;
		customer=entity.find(Customer.class,customer_mobile_no);
		return customer;
	}

}
