package com.capgemini.RegisterCustomer.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.RegisterCustomer.bean.Address;
import com.capgemini.RegisterCustomer.bean.Customer;
import com.capgemini.RegisterCustomer.exception.CustomerAlreadyExist;
import com.capgemini.RegisterCustomer.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService service;	

	String id;
	@RequestMapping(value="/")
	public String createProduct()  {
		return "registerCustomer";
	}
	
	@RequestMapping(value="/addresspage")
	public String addAddress(@Valid @ModelAttribute("customer") Customer customer) throws CustomerAlreadyExist  {
		
		 service.registerCustomer(customer);
		 id=customer.getCustomer_mobile_no();
		 return "addresspage";
	}
	
	@RequestMapping(value="/success")
	public String registered(@Valid @ModelAttribute("address") Address address)  {
		System.out.println(address);
		 service.addAddress(address,id);
		 return "sucess";
	}
}
