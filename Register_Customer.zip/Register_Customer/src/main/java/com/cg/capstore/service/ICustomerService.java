package com.cg.capstore.service;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.CustomerAlreadyExist;

public interface ICustomerService {

	public Customer registerCustomer(Customer customer) throws CustomerAlreadyExist ;
	public Address addAddress(Address address, String id);
}
