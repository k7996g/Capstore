package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.CustomerAlreadyExist;
import com.cg.capstore.repo.ICustomerRepository;



@Service("service")
public class CustomerService implements ICustomerService{

	@Autowired
	ICustomerRepository repo;
	
	@Override
	public Customer registerCustomer(Customer customer) throws CustomerAlreadyExist {
		if(repo.findCustomerByMobileNo(customer.getCustomerMobileNo()) == null)
			return repo.registerCustomer(customer) ;
		else
			throw new CustomerAlreadyExist("Customer Already exist with this Mobile Number");
		
	}

	@Override
	public Address addAddress(Address address,String id) {
		return repo.addAddress(address,id);
	}

	
}
